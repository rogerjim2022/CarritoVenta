import { Component, OnInit } from '@angular/core';
import { Product} from '../../models/product.model';
import { StoreService} from '../../services/store.service';
import { ServiceProductsService} from '../../services/service-products.service';


@Component({
  selector: 'app-products-list',
  templateUrl: './products-list.component.html',
  styleUrls: ['./products-list.component.scss']
})
export class ProductsListComponent implements OnInit {

myShoppingCart: Product [] = [];
nTotal = 0;

products: Product[] = [];
today = new Date();
date = new Date(2021,1,21);

constructor(
private storeService: StoreService,
private  serviceProductsService : ServiceProductsService
){
this.myShoppingCart=this.storeService.getmyShoppingCart();
}

//definir un array con el tipo de dato del modelo
  //las variables deben tener el mismo nombre de las variables
  //del modelo

  ngOnInit(): void {
    this.serviceProductsService.getAllProducts()
    .subscribe(data=>{
      // console.log(data);
      this.products=data;
    })
  }

  // products: Product[] = [
  //   {
  //     id:'1',
  //     name:'Ropa de mujer',
  //     precio:230.22,
  //     image:'./assets/img/ropa1.png',
  //   },
  //   {
  //     id:'2',
  //     name:'Ropa de chica',
  //     precio:260.22,
  //     image:'./assets/img/ropa2.png',
  //   },
  //   {
  //     id:'3',
  //     name:'Ropa de joven',
  //     precio:360.22,
  //     image:'./assets/img/ropa3.png',
  //   },
  //   {
  //     id:'4',
  //     name:'Ropa de joven',
  //     precio:460.22,
  //     image:'./assets/img/ropa4.png',
  //   }    ,
  //   {
  //     id:'5',
  //     name:'Ropa de joven',
  //     precio:330.22,
  //     image:'./assets/img/ropa5.png',
  //   }    ,
  //   {
  //     id:'6',
  //     name:'Ropa de joven',
  //     precio:223.22,
  //     image:'./assets/img/ropa6.png',
  //   }
  // ];



  onAddToShoppingCart(product: Product){
  // console.log(product);
  // this.myShoppingCart.push(product);

this.storeService.addProduct(product);
  // this.nTotal = this.myShoppingCart.reduce((sum,item)=>sum+item.precio,0);
  this.nTotal=this.storeService.getTotal();
  }

}
