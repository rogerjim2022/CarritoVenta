import { Component } from '@angular/core';
import { Product } from './models/product.model';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  imgParent = '';
  showImg=true;



  onLoaded(img: string){
    console.log('LOG PADRE',img);
  }

  // product: Product={
  //   id:'1',
  //   name:'Product 1',
  //   image:'./assets/img/ropa1.png',
  //   precio: 100
  // }

toggleImg(){
this.showImg=!this.showImg;
}

}
