import { Component, Input, Output,EventEmitter } from '@angular/core';
import { Product} from '../../models/product.model';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.scss']
})
export class ProductComponent {

  //las variables deben tener el mismo nombre de las variables
  //del modelo

  //iniciar en un estado por defecto
@Input() product: Product={
  id:'',
  title:'',
  description:'',
  category:'',
  image:'',
  price: 0
};

@Output() addEdProduct = new EventEmitter<Product>();


onAddToCart(){
this.addEdProduct.emit(this.product);
}

}
