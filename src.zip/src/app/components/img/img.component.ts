import { Component, OnInit, Input,Output, EventEmitter,OnChanges, SimpleChanges,AfterViewInit,OnDestroy, SimpleChange } from '@angular/core';

@Component({
  selector: 'app-img',
  templateUrl: './img.component.html',
  styleUrls: ['./img.component.scss']
})
export class ImgComponent implements OnInit, OnChanges,AfterViewInit,OnDestroy {
//separar la imagen del input
img: string = '';

@Input('img')
set changeImg(newImg: string){
    this.img=newImg;
    console.log('change just img',this.img);
    //codigo
}

@Input() alt: string='';

@Output() loaded=new EventEmitter <string>() ;

imageDefault='./assets/img/nada.jpg';
// counter=0;
// counterFn: number | undefined;

constructor(){
  //no se debe correr cosas asincronas, crea una vez
console.log('constructor','imgValue=>', this.img);
}
//actualiza cambios en el Input -- corre muchas veces
ngOnChanges(changes: SimpleChanges): void {
  console.log('ngOnChanges','imgValue=>', this.img);
}

ngOnInit(): void {
  console.log('ngOnInit','imgValue=>', this.img);
//  this.counterFn = window.setInterval(()=>{
//     this.counter=this.counter+1;
//     console.log('contador corriendo');
//   },1000);
}
// se debe correr cosas asincronas, crea una vez

ngAfterViewInit(): void {
//Corre despues
//hijos
console.log('ngAfterViewInit');
}

ngOnDestroy(): void {
//corre cuando se elimina el componente
console.log('ngOnDestroy');
// window.clearInterval(this.counterFn);
}

imgError(){
this.img= this.imageDefault;
}

imgLoaded(){
console.log('LOG HIJO');
this.loaded.emit(this.img);
}

}
